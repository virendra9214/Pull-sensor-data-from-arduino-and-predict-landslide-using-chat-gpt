import cv2
import numpy as np

def calculate_ndvi_from_video(url):
    cap = cv2.VideoCapture(url)
    frames = []
    
    # Capture frames until the video ends or reaches 10 frames
    while len(frames) < 10:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)

    if len(frames) < 10:
        print("The video has less than 10 frames.")
        cap.release()
        cv2.destroyAllWindows()
        return None

    green_intensities = []
    
    # Process the last 10 frames
    for frame in frames[-10:]:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower_green = np.array([35, 100, 100])
        upper_green = np.array([85, 255, 255])

        # Mask and calculate green intensity
        mask = cv2.inRange(hsv, lower_green, upper_green)
        green_intensity = np.sum(mask) / (mask.size * 255)
        green_intensities.append(green_intensity)
    
    # Calculate the average green intensity over the last 10 frames
    fake_ndvi = np.mean(green_intensities)

    print(f"NDVI: {fake_ndvi}")

    cap.release()
    cv2.destroyAllWindows()
    return fake_ndvi
# Example usage

