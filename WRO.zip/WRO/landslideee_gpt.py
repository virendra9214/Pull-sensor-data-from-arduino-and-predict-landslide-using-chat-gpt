from g4f.client import Client
from nvdi import calculate_ndvi_from_video
#url = "http://192.168.29.56:8080/video"
def predict_landslide_chances(a, c, d, e , url):
    
    ndvi_value = calculate_ndvi_from_video(url)
    b = ndvi_value
    print(b)
    client = Client()
    print(ndvi_value)
    data_reference = """
    Date,Location,Coordinates (Lat,Long),Average Temperature (°C),Estimated NDVI,Average Monthly Rainfall (mm),Elevation (m),Slope (degrees)
    1954,Calabria, Italy,39.466,16.466,12.5,0.5,100,500,5
    1963,Vajont Dam, Italy,46.234,12.287,12.5,0.6,120,800,30
    1999,Vargas State, Venezuela,10.485,-66.918,26,0.7,400,2000,10
    2005,Jember, Indonesia,-8.175,113.713,26.5,0.6,300,200,8
    2008,Sichuan, China,31.014,103.173,20,0.4,150,1500,20
    2010,Gansu, China,34.491,103.844,25,0.3,80,2000,15
    2014,Badulla, Sri Lanka,6.986,81.033,21.5,0.7,500,1000,25
    2015,Nepal,28.394,84.124,20,0.5,200,2500,35
    2020,Mocoa, Colombia,1.157,-77.062,23,0.8,300,2000,15
    2004,Freetown, Sierra Leone,8.465,-13.231,27,0.6,350,50,2
    2008,Burundi,-3.514,29.549,22.5,0.6,150,1600,12
    2018,Mbotyi, South Africa,-31.637,29.670,23.5,0.5,180,300,10
    1960,Bregaglia, Switzerland,46.326,9.542,12.5,0.4,120,1500,40
    1979,Mount Etna, Italy,37.751,14.995,12.5,0.5,80,3300,35
    1996,Piz Cengalo, Switzerland,46.368,9.693,15,0.3,150,3300,40
    2005,La Palma, Spain,28.692,-17.788,22.5,0.5,1000,2300,25
    2013,Cuneo, Italy,44.389,7.541,12.5,0.4,90,500,10
    1964,Good Friday, Alaska, USA,61.217,-149.900,-0,0.2,400,0,5
    1970,Yungay, Peru,-9.136,-77.760,15,0.7,120,2500,30
    1996,Glenwood Springs, Colorado, USA,39.550,-107.325,25,0.4,2300,25
    2005,La Conchita, California, USA,34.413,-119.510,14,0.3,50,10
    2014,Oso, Washington, USA,48.063,-122.257,7.5,0.4,100,15
    2010,Potosí, Bolivia,-19.584,-65.751,10,0.5,4000,20
    2017,Mocoa, Colombia,1.157,-77.062,23,0.8,2000,15
    2019,Arequipa, Peru,-16.409,-71.537,15,0.6,2300,25
    2009,Christchurch, New Zealand,-43.532,172.636,10.5,0.4,30,3
    2016,Queenstown, New Zealand,-45.031,168.662,3,0.3,300,10
    2020,Gunnedah, Australia,-30.982,150.215,27.5,0.6,400,5
    """
    prompt = f"""Pridict the chances of landslide according to this data : average temp : {a}, NDVI :{b}, monthy rainfall: {c},elivation : {d}, slope: {e} use thisdata as refrence :
    {data_reference}
    """
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
    )
    print(response.choices[0].message.content)