# First script (main.py)
from landslideee_gpt import predict_landslide_chances # NDVI is calculated once
url = "http://192.168.29.56:8080/video"
a = input("Average temperature (°C): ").strip()
c = input("Monthly rainfall (mm): ").strip()
d = input("Elevation (m): ").strip()
e = input("Slope (degrees): ").strip()

#print(f"NDVI (float): {b}")

predict_landslide_chances(a ,c , d , e, url)

