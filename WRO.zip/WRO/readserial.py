import serial
import time

# Define the serial port and baud rate. You need to adjust these values according to your setup.
SERIAL_PORT = 'COM8'  # Replace with your actual serial port
BAUD_RATE = 9600

def parse_data(data):
    """Parse the incoming data and filter it by type."""
    if data.startswith("m"):
        print(f"Soil Moisture: {data[1:]}")
    elif data.startswith("T"):
        print(f"Temperature (DHT): {data[1:]} °C")
    elif data.startswith("H"):
        print(f"Humidity (DHT): {data[1:]} %")
    elif data.startswith("X"):
        print(f"MPU6050 Temperature: {data[1:]} °C")
    elif data.startswith("a"):
        print(f"Latitude: {data[1:]}")
    elif data.startswith("o"):
        print(f"Longitude: {data[1:]}")
    else:
        print(f"Unknown Data: {data}")

def read_from_serial(port, baud_rate):
    try:
        # Initialize serial connection
        ser = serial.Serial(port, baud_rate, timeout=1)
        print(f"Connected to {port} at {baud_rate} baud rate.")
        
        while True:
            # Read all available data
            if ser.in_waiting > 0:
                data = ser.readline().decode('utf-8').strip()
                if data:
                    parse_data(data)
            
            # Add a small delay to prevent high CPU usage
            time.sleep(0.1)

    except serial.SerialException as e:
        print(f"Error: {e}")
    except KeyboardInterrupt:
        print("\nExiting...")
    finally:
        if ser.is_open:
            ser.close()
            print("Serial port closed.")

if __name__ == "__main__":
    read_from_serial(SERIAL_PORT, BAUD_RATE)
